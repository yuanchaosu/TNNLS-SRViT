import numpy as np
from scipy.sparse.linalg import svds
"-------------------------------------------------------------------------"
"This code is designed for making synthetic data."
" Mar. 2023 "
"-------------------------------------------------------------------------"


def data_proj(y, p, **kwargs):
    L, samp_size = y.shape
    proj_type = kwargs.get('proj_type', 'affine')
    my = np.mean(y, axis=1, keepdims=True)
    if proj_type == 'ml':
        Up, D, _ = svds(y @ y.T / samp_size, p)
        sing_val = np.diag(D)
        yp = Up.T @ y
    elif proj_type == 'affine':
        yp = y - my
        Up, D, _ = svds(yp @ yp.T / samp_size, p - 1)
        yp = Up @ Up.T @ yp
        yp = yp + my
        my_ortho = my - Up @ Up.T @ my
        Up = np.hstack([Up, my_ortho / np.sqrt(np.sum(my_ortho ** 2))])
        sing_val = np.diag(D)
    else:
        raise ValueError(f"Unrecognized option: '{proj_type}'")

    return yp, Up, my, sing_val

