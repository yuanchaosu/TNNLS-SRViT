    plot(E,'black','LineWidth',5);
    ylabel('Reflectance','fontsize',20);
    xlabel('Bands','fontsize',20);
    set(gca,'FontSize',15);
%     title('Endmembers','fontsize',12);
    hold off