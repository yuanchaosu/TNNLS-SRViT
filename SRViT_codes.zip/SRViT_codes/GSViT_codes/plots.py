import numpy as np
from matplotlib import pyplot as plt
"-----------------------------------------------------------------------------------------"
"These auxiliary codes come from DeepTrans-HSU's attachment."
"-----------------------------------------------------------------------------------------"


def plot_abundance(ground_truth, estimated, em, save_dir):
    em = ground_truth.shape[2]
    plt.figure(figsize=(12, 6), dpi=150)
    for i in range(em):
        plt.subplot(2, em, i + 1)
        rotated_slice = np.rot90(ground_truth[:, :, i], k=-1)
        flipped_slice = np.fliplr(rotated_slice)
        plt.imshow(flipped_slice, cmap='jet')
        plt.axis('off')
        plt.title(f'Ground-Truth Endm{i + 1}', fontsize=8)

    for i in range(em):
        plt.subplot(2, em, em + i + 1)
        rotated_slice = np.rot90(estimated[:, :, i], k=-1)
        flipped_slice = np.fliplr(rotated_slice)
        plt.imshow(flipped_slice, cmap='jet')
        plt.axis('off')
        plt.title(f'SEViT Endm {i + 1}', fontsize=8)
