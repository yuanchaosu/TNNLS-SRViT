from scipy.io import loadmat
from scipy.sparse.linalg import svds
from torchsummary import summary
import torchvision.transforms as transforms
import plotly.graph_objects as go
import torch.utils.data
import scipy.io as sio
import torch.nn as nn
import numpy as np
import torch
import math
import plots
import utils
import gsvit_tnt
import gsvit_emb
import os
import vca
import dataPro
import webbrowser
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
"-----------------------------------------------------------------------------------------------------------"
"SRViT: Self-Supervised Relation-Aware Vision Transformer for Hyperspectral Unmixing"
"GSViT codes are intended for academic communication only and may not be used commercially."
"Our work uses Python 3.8 and Pytorch 2.0 + cudnn 11.8"
"Acknowledge: Our some auxiliary codes referred to DeepTrans-HSU."
"Authors: Yuanchao Su, Lianru Gao, Mengying Jiang, Antonio Plaza, Xu Sun, and Guang Yang"
"Email: suych3@xust.edu.cn /  gaolr@aircas.ac.cn"
"Mar. 2023"
"-----------------------------------------------------------------------------------------------------------"

class Discriminator(nn.Module):
    def __init__(self, n_h):
        super(Discriminator, self).__init__()
        self.n_h = n_h
        self.f_k = nn.Bilinear(n_h, n_h, 1)

        for m in self.modules():
            self.weights_init(m)

    def weights_init(self, m):
        if isinstance(m, nn.Bilinear):
            torch.nn.init.xavier_uniform_(m.weight.data)
            if m.bias is not None:
                m.bias.data.fill_(0.0)

    def forward(self, x_embed, position_embed):
        x_embed = x_embed.view(-1, self.n_h)
        position_embed = position_embed.view(-1, self.n_h)
        scores = self.f_k(x_embed, position_embed)
        return scores

class SE_AE(nn.Module):
    def __init__(self, position_dim, P, L, size, patch, dim, inner_dim):
        super(SE_AE, self).__init__()
        self.P, self.L, self.size, self.patch, self.dim, self.inner_dim = P, L, size, patch, dim, inner_dim
        self.encoder = gsvit_tnt.TNT(img_size=size, patch_size=patch, in_chans=L, outer_dim=(dim * P),
                                     inner_dim=(inner_dim * P), depth=2, outer_num_heads=8, inner_num_heads=4,
                                     mlp_ratio=4, qkv_bias=False, qk_scale=None, drop_rate=0., attn_drop_rate=0.,
                                     drop_path_rate=0., norm_layer=gsvit_tnt.ContraNorm, inner_stride=1)
        self.encoder_position = gsvit_tnt.TNT(img_size=size, patch_size=patch, in_chans=position_dim,
                                              outer_dim=(dim * P), inner_dim=(inner_dim * P), depth=2,
                                              outer_num_heads=8, inner_num_heads=4, mlp_ratio=4,
                                              qkv_bias=False, qk_scale=None, drop_rate=0., attn_drop_rate=0.,
                                              drop_path_rate=0., norm_layer=gsvit_tnt.ContraNorm, inner_stride=1)

        self.disc = Discriminator(P * dim)

        self.upscale = nn.Sequential(
            nn.Linear(inner_dim, size ** 2),
        )
        self.smooth = nn.Sequential(
            nn.Conv2d(P, P, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1)),
            nn.Softmax(dim=1),
        )
        self.decoder = nn.Sequential(
            nn.Conv2d(P, L, kernel_size=(1, 1), stride=(1, 1), bias=False),
            nn.ReLU(),
        )
    @staticmethod
    def weights_init(m):
        if type(m) == nn.Conv2d:
            nn.init.kaiming_normal_(m.weight.data)

    def forward(self, x, position_code):
        abu_est = self.encoder(x)
        abu_position_code = self.encoder_position(position_code)
        cls_emb = (abu_est*abu_position_code).view(1, self.P, -1)
        ret_os = self.disc(abu_est, abu_position_code)
        abu_est = self.upscale(cls_emb).view(1, self.P, self.size, self.size)
        abu_est = self.smooth(abu_est)
        re_result = self.decoder(abu_est)
        return abu_est, re_result, ret_os

class TrainData(torch.utils.data.Dataset):
    def __init__(self, img, target, transform=None, target_transform=None):
        self.img = img.float()
        self.target = target.float()
        self.transform = transform
        self.target_transform = target_transform

    def __getitem__(self, index):
        img, target = self.img[index], self.target[index]
        if self.transform:
            img = self.transform(img)
        if self.target_transform:
            target = self.target_transform(target)
        return img, target

    def __len__(self):
        return len(self.img)


class Data:
    def __init__(self, dataset, device):
        super(Data, self).__init__()
        if dataset == 'synthetic':
            data_path = "./data_synthetic/" + dataset + ".mat"
            data = sio.loadmat(data_path)
            self.Y = torch.from_numpy(data['Y'].T).to(device)
            self.A = torch.from_numpy(data['A'].T).to(device)
            self.M = torch.from_numpy(data['M'])
        elif dataset == 'real':
            data_path = "./data_real/" + dataset + ".mat"
            data = sio.loadmat(data_path)
            self.Y = torch.from_numpy(data['Y'].T).to(device)
            self.A = torch.from_numpy(data['A'].T).to(device)
            self.M = torch.from_numpy(data['M'])
        else:
            raise ValueError("Unknown dataset")

    def get(self, typ):
        if typ == "hs_img":
            return self.Y.float()
        elif typ == "abd_map":
            return self.A.float()
        elif typ == "end_mem":
            return self.M
        elif typ == "init_weight":
            return self.M

    def get_loader(self, batch_size=1):
        train_dataset = TrainData(img=self.Y, target=self.A, transform=transforms.Compose([]))
        train_loader = torch.utils.data.DataLoader(dataset=train_dataset, batch_size=batch_size, shuffle=False)
        return train_loader


class Train_test:
    def __init__(self, device, dataset, skip_train=False, save=False):
        super(Train_test, self).__init__()
        self.skip_train = skip_train
        self.device = device
        self.dataset = dataset
        self.save = save
        self.save_dir = 'GSViT_results_' + dataset + '/'
        os.makedirs(self.save_dir, exist_ok=True)
        if dataset == 'synthetic':
            self.P, self.col = 6, 18
            self.LR, self.EPOCH = 6e-3, 100
            self.patch, self.dim = 10, 64
            self.beta, self.gamma = 5e3, 5e-2
            self.weight_decay_param = 4e-5
            self.order_abd, self.order_endmem = (0, 1, 2, 3, 4, 5), (0, 1, 2, 3, 4, 5)
            self.data = Data(dataset, device)
            self.loader = self.data.get_loader(batch_size=self.col ** 2)
            self.init_weight = self.data.get("init_weight").unsqueeze(2).unsqueeze(3).float()
        elif dataset == 'real':
            self.P, self.col = 3, 95
            self.LR, self.EPOCH = 6e-3, 50
            self.patch, self.dim = 10, 64
            self.beta, self.gamma = 5e3, 5e-2
            self.weight_decay_param = 4e-5
            self.order_abd, self.order_endmem = (0, 1, 2), (0, 1, 2)
            self.data = Data(dataset, device)
            self.loader = self.data.get_loader(batch_size=self.col ** 2)
            self.init_weight = self.data.get("init_weight").unsqueeze(2).unsqueeze(3).float()
        else:
            raise ValueError("Unknown dataset")
# ** Pixel-Position Coding **
        window = 3  # Int_indow size
        length = 7  # out_window size
        n_r = math.ceil(self.col / window)
        n_c = math.ceil(self.col / window)
        position_matrix = np.zeros((self.col, self.col))
        i = 1
        for x in range(n_r):
            for y in range(n_c):
                if x < (n_r - 1):
                    if y < (n_c - 1):
                        position_matrix[x * window:(x * window + window), y * window:(y * window + window)] = i
                        i = i + 1
                    else:
                        position_matrix[x * window:(x * window + window), y * window:] = i
                        i = i + 1
                else:
                    if y < (n_c - 1):
                        position_matrix[x * window:, y * window:(y * window + window)] = i
                        i = i + 1
                    else:
                        position_matrix[x * window:, y * window:] = i
                        i = i + 1
        num_position = n_r * n_c
        half = (length - 1) // 2
        position_fea = np.zeros((self.col + length, self.col + length))

        position_fea[half:half + self.col, half:half + self.col] = position_matrix
        self.position_dim = n_r * n_c
        position_code = np.zeros((self.col, self.col, n_r * n_c))
        position_vector = np.zeros((n_r * n_c))
        for i in range(self.col):
            for j in range(self.col):
                x = i + half
                y = j + half
                window_num = position_fea[(x-half):(x + half), (y-half):(y+half)]
                window_num = window_num.reshape(1, -1)
                window_num = window_num[window_num != 0] - 1
                unique_num, unique_count = np.unique(window_num, return_counts=True)
                unique_num = np.array(unique_num, dtype=int)
                position_vector[unique_num] = unique_count
                position_code[i, j, :] = position_vector
        self.position_code = position_code

    def run(self, smry, dataset):
        if dataset == 'synthetic':
            data = loadmat('./data_synthetic/synthetic.mat')
            self.xm = (np.array(data['Y'])).T
            self.L, self.pixels = self.xm.T.shape
            self.edm = (np.array(data['M'])).T
            abm = (np.array(data['A'])).T
        elif dataset == 'real':
            data = loadmat('./data_real/real.mat')
            self.xm = (np.array(data['Y'])).T
            self.L, self.pixels = self.xm.T.shape
            self.edm = (np.array(data['M'])).T
        else:
            raise ValueError("Unknown dataset")
        net = SE_AE(self.position_dim, P=self.P, L=self.L, size=self.col, patch=self.patch, dim=self.dim, inner_dim=self.dim)\
            .to(self.device)
        if smry:
            summary(net, (1, self.L, self.col, self.col))
            return
        net.apply(net.weights_init)
        model_dict = net.state_dict()
        model_dict['decoder.0.weight'] = self.init_weight
        net.load_state_dict(model_dict)
        loss_1 = nn.MSELoss(reduction='mean')
        loss_2 = utils.SAD(self.L)
        optimizer = torch.optim.Adam(net.parameters(), lr=self.LR, weight_decay=self.weight_decay_param)
        scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=15, gamma=0.8)
        apply_clamp_inst1 = gsvit_tnt.NonZeroClipper()
        position_code = self.position_code
        position_code = torch.tensor(position_code).to(self.device)
        position_code = position_code.float()
        position_code = position_code.view(1, -1, self.col, self.col)
        if not self.skip_train:
            net.train()
            epo_vs_los = []
            for epoch in range(self.EPOCH):
                model = gsvit_emb.reconsitution(L=self.L, P=self.P, init_edm=self.edm.T, height=self.col,
                                                width=self.col, version='com', seed=30)
                abd = model.fit(self.xm.reshape(-1, self.L).T, max_iter=100).T
                for i, (x, _) in enumerate(self.loader):
                    x = x.transpose(1, 0).view(1, -1, self.col, self.col)
                    abu_est, re_result, ret_os = net(x, position_code)
                    loss_re = self.beta * loss_1(re_result, x)
                    loss_sad = loss_2(re_result.view(1, self.L, -1).transpose(1, 2),
                                          x.view(1, self.L, -1).transpose(1, 2))
                    loss_sad = self.gamma * torch.sum(loss_sad).float()

                    b_xent = nn.BCEWithLogitsLoss().to(self.device)
                    lbl = (torch.ones(ret_os.shape[0], 1)).to(self.device)
                    loss_ss = b_xent(ret_os, lbl.float())
                    total_loss = loss_re + loss_sad + 1*loss_ss
                    # total_loss = loss_re + loss_sad
                    optimizer.zero_grad()
                    total_loss.backward()
                    nn.utils.clip_grad_norm_(net.parameters(), max_norm=10, norm_type=1)
                    optimizer.step()
                    net.decoder.apply(apply_clamp_inst1)
                    if epoch % 10 == 0:
                        print('Epoch:', epoch, '| train loss: %.4f' % total_loss.data,
                              '| re loss: %.4f' % loss_re.data,
                              '| sad loss: %.4f' % loss_sad.data)
                    epo_vs_los.append(float(total_loss.data))
                scheduler.step()
# ** Testing **
                net.eval()
                x = self.data.get("hs_img").transpose(1, 0).view(1, -1, self.col, self.col)
                self.hid_nodes, self.re_result, ret_os = net(x, position_code)
                if dataset == 'synthetic':
                    self.abd1 = abm.reshape(self.col, self.col, self.P)
                    self.a0 = abm.T
                    self.hid_nodes = ((self.hid_nodes / (torch.sum(self.hid_nodes, dim=1))).squeeze(0).permute(1, 2, 0).
                                      detach().cpu().numpy()) * self.abd1
                elif dataset == 'real':
                    self.abd1 = abd.reshape(self.col, self.col, self.P)
                    self.a0 = abd.T
                    self.hid_nodes = ((self.hid_nodes / (torch.sum(self.hid_nodes, dim=1))).squeeze(0).permute(1, 2, 0).
                                      detach().cpu().numpy()) * self.abd1
                else:
                    raise ValueError("Unknown dataset")
                node_emb = np.add(self.abd1, self.hid_nodes)
                target = torch.reshape(self.data.get("abd_map"), (self.col, self.col, self.P)).cpu().numpy()
                h_o_weights = (net.state_dict()["decoder.0.weight"].cpu().numpy()).reshape((self.L, self.P))
                h_o_weights = h_o_weights[:, self.order_endmem]
                node_emb = node_emb[:, :, self.order_abd]
                abu_est_sav = node_emb.reshape(self.col * self.col, self.P).T
                my = np.mean(self.xm.T, axis=1)[:, np.newaxis]
                y0 = self.xm.T - my
                up, do, _ = svds(y0 @ y0.T / self.pixels, self.P - 1)
                y0 = (up @ up.T @ y0) + my
                my_ortho = my - up @ up.T @ my
                up = np.hstack((up, my_ortho / np.sqrt(np.sum(my_ortho ** 2))))
                y0 = up @ (up.T @ y0)
                y0 = y0 - my
                c = np.diag(1. / np.sqrt(np.diag(do + 1e-8 * np.eye(self.P - 1))))
                ic = np.linalg.inv(c)
                y0 = c @ up[:, :self.P - 1].T @ y0
                y0 = np.vstack((y0, np.ones((1, self.pixels))))
                y0 = y0 / np.sqrt(self.P)
                e_vca, _, _ = vca.VCA(y0, self.P, verbose=True, snr_input=0)
                ym = np.mean(e_vca, axis=1)[:, np.newaxis]
                e1 = e_vca + self.P * (e_vca - ym)
                q1 = np.linalg.inv(e1)
                sevitemb = gsvit_emb.weighconst(self.xm.T, y0, h_o_weights, self.a0, q1, up, ic, my, self.P)
                endm_weig = sevitemb.run()
# "Showing results in feature space."
##################################################################################################################
        if dataset == 'synthetic':
            data_path = "./data_synthetic/synthetic.mat"
            data = sio.loadmat(data_path)
            M = torch.from_numpy(data['M'])
            y1, upo, _, _ = dataPro.data_proj(self.xm.T, self.P, proj_type='affine')
            y1 = upo.T @ y1
            m_numpy = M.numpy()
            mtrue = upo.T @ m_numpy
            mendms = upo.T @ endm_weig
            ik, jk, kk = 0, 1, 2
            e_i = np.eye(self.P)
            v1, v2, v3 = e_i[:, ik], e_i[:, jk], e_i[:, kk]
            y1 = np.vstack([v1, v2, v3]) @ y1
            m_true = np.vstack([v1, v2, v3]) @ mtrue
            m_mendms = np.vstack([v1, v2, v3]) @ mendms
            scatter_data = go.Scatter3d(x=y1[0, :], y=y1[1, :], z=y1[2, :], mode='markers',
                                        marker=dict(size=5, color='#008B8B'), name='Mixed Pixels')
            scatter_m_true = go.Scatter3d(x=m_true[0, :], y=m_true[1, :], z=m_true[2, :], mode='markers',
                                          marker=dict(size=7, color='black'), name='Ground-Truth')
            scatter_m_mendms = go.Scatter3d(x=m_mendms[0, :], y=m_mendms[1, :], z=m_mendms[2, :], mode='markers',
                                            marker=dict(size=13, color='rgba(217, 83, 25, 0.8)', symbol='diamond'),
                                            name='GSViT Endmembers')
            data = [scatter_data, scatter_m_true, scatter_m_mendms]
            layout = go.Layout(title='GSViT Test', scene=dict(xaxis_title='X', yaxis_title='Y', zaxis_title='Z'))
            fig = go.Figure(data=data, layout=layout)
            html_filename = '3d visualization.html'
            fig.write_html(html_filename)
            # webbrowser.open('file://' + os.path.realpath(html_filename))
#           # color='black
#             data0 = [scatter_data, scatter_m_true]
#             fig = make_subplots(rows=1, cols=2, specs=[[{'type': 'scatter3d'}, {'type': 'scatter3d'}]])
#             fig.add_trace(scatter_data, row=1, col=1)
#             fig.add_trace(scatter_m_true, row=1, col=1)
#             fig.add_trace(scatter_data, row=1, col=2)
#             fig.add_trace(scatter_m_true, row=1, col=2)
#             fig.add_trace(scatter_m_mendms, row=1, col=2)
#             fig.update_layout(
#                 title='SEViT',
#                 scene=dict(xaxis_title='X', yaxis_title='Y', zaxis_title='Z'),
#                 scene2=dict(xaxis_title='X', yaxis_title='Y', zaxis_title='Z')
#             )
#             html_filename = '3d_scatter.html'
#             fig.write_html(html_filename)
            webbrowser.open('file://' + os.path.realpath(html_filename))
##################################################################################################################
        abu_rotated = np.rot90(node_emb, k=self.P)
        abu_rotated_flipped = np.flip(abu_rotated, axis=1)
        sio.savemat(self.save_dir + f"{self.dataset}_endmem.mat", {"E_est": endm_weig})
        sio.savemat(self.save_dir + f"{self.dataset}_abd_map.mat", {"A_est": abu_est_sav})
        sio.savemat(self.save_dir + f"{self.dataset}_abd_cude.mat", {"abu_cude_sav": abu_rotated_flipped})
        x = x.view(-1, self.col, self.col).permute(1, 2, 0).detach().cpu().numpy()
        re = self.re_result.view(-1, self.col, self.col).permute(1, 2, 0).detach().cpu().numpy()
        re = utils.compute_re(x, re)
        print("RE:", re)
        plots.plot_abundance(target, node_emb, self.P, self.save_dir)
        return node_emb, endm_weig, abu_rotated_flipped