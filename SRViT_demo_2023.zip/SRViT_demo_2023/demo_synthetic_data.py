import random
import torch
import scipy.io as sio
import matplotlib.pyplot as plt
from synthetic_data import *
from vca import *
import GSViT
import os
"-----------------------------------------------------------------------------------------------------------"
"SRViT: Vision Transformer for Hyperspectral Image Unmixing "
"Our work uses Python 3.8 and Pytorch 2.0 + cudnn 11.8"
" Authors: Yuanchao Su, Lianru Gao, Antonio Plaza, Mengying Jiang, Xu Sun and Guang Yang "
" This demo is used for evaluating SEViT."
" We creat sythetic datasets that randomly select library signatures. "
" Mar. 2023 "
"-----------------------------------------------------------------------------------------------------------"
# Test SEViT    ############################################################################################
if __name__ == '__main__':
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    print("\nSelected device:", device, end="\n\n")
    P = 6  # The number of endmembers
    Outliers = 0  # The number of outliers
    MaxPurity = 0.8  # max purity
    SNR = 60  # SNR(dB)
    Y, A, M = linear_syn(P, SNR, MaxPurity)
    save_dir = "data_" + 'synthetic' + "/"
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    sio.savemat(save_dir + 'synthetic.mat', mdict={'Y': Y, 'A': A, 'M': M})
    seed = 1
    random.seed(seed)
    torch.manual_seed(seed)
    np.random.seed(seed)
    model = GSViT.Train_test(dataset='synthetic', device=device, skip_train=False, save=True)
    model.run(smry=False, dataset='synthetic')
    Abu_results = loadmat('./GSViT_results_synthetic/synthetic_abd_cude.mat')
    abu_cude = np.array(Abu_results['abu_cude_sav'])
    E_results = loadmat('./GSViT_results_synthetic/synthetic_endmem.mat')
    E = np.array(E_results['E_est'])
# Show abundances   ##########################################################################################
    fig, axes = plt.subplots(1, P, figsize=(10, 3))
    for i, ax in enumerate(axes):
        ax.imshow(abu_cude[:, :, i], cmap='gray')
        ax.axis('off')
        ax.set_title(f'GSViT {i + 1}', fontsize=8)
    plt.tight_layout()
    plt.show()
#  Compared VCA    ############################################################################################
    endm_vca, _, Yp = VCA(Y, 6, verbose=True, snr_input=0)
# Comparing endmembers
fig, ax = plt.subplots(nrows=2, ncols=1, figsize=(5, 7))
ax[0].plot(endm_vca, 'r', linewidth=2)
ax[0].plot(M, '-.', color=[0, 0.45, 0.74], linewidth=2)
ax[0].set_ylabel('Reflectance', fontsize=15)
ax[0].set_xlabel('Bands', fontsize=15)
endm_vca0 = endm_vca[:,0]
M0 = M[:,0]
sh1 = ax[0].plot(endm_vca0, 'r', linewidth=2, label='Estimated')
sh2 = ax[0].plot(M0, '-.', color=[0, 0.45, 0.74], linewidth=2, label='Library')
ax[0].legend(loc='lower right')
ax[0].set_title('VCA')
ax[1].plot(E, 'r', linewidth=2)
ax[1].plot(M, '-.', color=[0, 0.45, 0.74], linewidth=2)
ax[1].set_ylabel('Reflectance', fontsize=15)
ax[1].set_xlabel('Bands', fontsize=15)
E0 = E[:,0]
M0 = M[:,0]
sh3 = ax[1].plot(E0, 'r', linewidth=2, label='Estimated')
sh4 = ax[1].plot(M0, '-.', color=[0, 0.45, 0.74], linewidth=2, label='Library')
ax[1].legend(loc='lower right')
ax[1].set_title('GSViT')
fig.tight_layout()
plt.show()