import matplotlib.pyplot as plt
import numpy as np
import matplotlib.pyplot as plt

plt.figure(figsize=(12,7),dpi=450)
plt.subplots_adjust(left=0.2, bottom=0.3, right=0.9, top=None, wspace=None, hspace=None)
# plt.xlabel('(c)',fontsize=25,labelpad=11)

plt.ylabel('OA (%)',fontsize=32,labelpad=11)

# plt.yticks([78, 88, 98]) # INDIAN
# plt.ylim(ymax=98, ymin=78) # task1

# plt.yticks([90, 93, 96 ]) # WUH
# plt.ylim(ymax=97, ymin=89.5) # task1

# plt.yticks([84, 88, 92]) # HU2013
# plt.ylim(ymax=92, ymin=83.6) # task1

plt.yticks([77, 81, 85, 89]) # HU2018
plt.ylim(ymax=89, ymin=77) # task1

#设置图框线粗细
bwith = 0.6 #边框宽度设置为2
TK = plt.gca()#获取边框
TK.spines['bottom'].set_linewidth(bwith)#图框下边
TK.spines['left'].set_linewidth(bwith)#图框左边
TK.spines['top'].set_linewidth(bwith)#图框上边
TK.spines['right'].set_linewidth(bwith)#图框右边
#

# y_data = [79.28, 91.19, 94.45, 95.23, 96.52, 97.04]  # INDIAN
# y_data = [90.04, 92.64, 95.05, 94.84, 95.61, 96.10]  # WUH
# y_data = [84.75, 84.35, 87.09, 89.30, 90.59, 91.35]  # HU2013
y_data = [77.85, 80.12, 81.77, 85.28, 87.12, 87.86]  # HU2018


samples =['GraphGST-X','GraphGST-H','GraphGST-P','GraphGST-C','GraphGST-V','GraphGST']
x = range(len(samples))
plt.xticks(x, samples, rotation=-30)
plt.tick_params(labelsize=32) #刻度字体大小13
plt.bar(x, y_data, color=['slategrey',  'lightsteelblue', 'cornflowerblue',  'royalblue', 'slateblue', 'darkslateblue'], width=0.8)
# plt.savefig('variants_INDIAN.pdf', bbox_inches='tight', dpi=450)
# plt.savefig('variants_WUH.pdf', bbox_inches='tight', dpi=450)
# plt.savefig('variants_HU2013.pdf', bbox_inches='tight', dpi=450)
plt.savefig('variants_HU2018.pdf', bbox_inches='tight', dpi=450)
plt.show()

