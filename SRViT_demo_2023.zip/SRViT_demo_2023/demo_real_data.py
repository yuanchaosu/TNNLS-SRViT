import random
import numpy as np
import matplotlib.pyplot as plt
from scipy.io import loadmat
import torch.utils.data
import GSViT

"-----------------------------------------------------------------------------------------------------------"
'SRViT: Vision Transformer for Hyperspectral Image Unmixing'
'This demo is used for evaluating SEViT.'
'Mar. 2023'
"-----------------------------------------------------------------------------------------------------------"

if __name__ == '__main__':
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    print("\nSelected device:", device, end="\n\n")
    seed = 1
    random.seed(seed)
    torch.manual_seed(seed)
    np.random.seed(seed)
    model = GSViT.Train_test(dataset='real', device=device, skip_train=False, save=True)
    model.run(smry=False, dataset='real')
    E_results = loadmat('./GSViT_results_real/real_endmem.mat')
    E = np.array(E_results['E_est'])
    Abu_results = loadmat('./GSViT_results_real/real_abd_cude.mat')
    abu_cude = np.array(Abu_results['abu_cude_sav'])
    P = 3
# 'Show endmembers and abundances'
    fig, axes = plt.subplots(2, P, figsize=(20, 12), gridspec_kw={'height_ratios': [1, 4]})
    for i in range(P):
        E_column = E[:, i]
        x = np.arange(len(E_column))
        axes[0, i].plot(x, E_column, 'r', linewidth=2)
        axes[0, i].set_title(f'Endmember  {i + 1}', fontsize=25)
        axes[0, i].set_xlabel('Bands', fontsize=20)
        axes[0, i].set_ylabel('Reflectance', fontsize=20)
    for i in range(P):
        axes[1, i].imshow(abu_cude[:, :, i], cmap='gray')
        axes[1, i].axis('off')
    plt.show()