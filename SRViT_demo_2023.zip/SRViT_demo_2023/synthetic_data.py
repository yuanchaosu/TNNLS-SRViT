import numpy as np
from scipy.signal import convolve2d
import os
from scipy.io import loadmat
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'

"---------------------------------------------------------------------------------------"
"This code is designed for making synthetic data."
"* Input *"
"P: Setting the number of endmembers."
"SNR: Signal to Noise Ratio for creating a synthetic data"
"MaxPurity: Deleting  pure pixels"
"* Output *"
"Y: synthetic data"
"M: library endmembers"
"X: library abundances"
"The codes is intended for academic communication only and may not be used commercially."
" Mar. 2023 "
"----------------------------------------------------------------------------------------"


def linear_syn(P, SNR, MaxPurity):
    # np.random.seed(5)
    data = loadmat('./USGS_Library/USGS_1995_Library.mat')
    datalib = data['datalib']
    bands, n_materiais = datalib.shape
    sel_mat = np.random.permutation(np.arange(4, n_materiais))
    sel_mat = sel_mat[:P]
    M = datalib[:, sel_mat]
    dimension = 24
    label = np.ones((dimension // 8) ** 2)
    num = len(label) // P
    for i in range(P - 1):
        label[i * num:(i + 1) * num] = i + 2
    ridx = np.random.permutation(len(label))
    label = label[ridx]
    label = label.reshape(dimension // 8, dimension // 8)
    X = np.zeros((dimension, dimension, P))
    img = np.zeros((dimension, dimension))
    for i in range(dimension):
        for j in range(dimension):
            for cls in range(P):
                if label[i // 8, j // 8] == cls + 1:
                    tmp = np.zeros(P)
                    tmp[cls] = 1
                    X[i, j, :] = tmp
                    img[i, j] = P
    win = 7
    H = np.ones((win, win)) / (win * win)
    for i in range(P):
        X[:, :, i] = convolve2d(X[:, :, i], H, mode='same')
    X = X[win // 2:-win // 2 + 1, win // 2:-win // 2 + 1, :]
    m, n,_ = X.shape
    X = X.reshape(m * n, P).T
    indices = np.argwhere(X > MaxPurity)
    Index = indices[:, 1]
    X[:, Index] = 1 / P * np.ones((P, len(Index)))
    HIM = (M @ X).T.reshape(m, n, bands)
    Y = HIM.reshape(m * n, bands)
    X = X.astype(np.float32)
    if SNR < 100:
        variance = np.sum(Y ** 2) / (10 ** (SNR / 10)) / m / n / bands
        noise = np.sqrt(variance) * np.random.randn(bands, m * n)
        Y = Y.T + noise
        Y = Y.astype(np.float32)
    else:
        Y = Y.T
        Y = Y.astype(np.float32)
    return Y, X, M